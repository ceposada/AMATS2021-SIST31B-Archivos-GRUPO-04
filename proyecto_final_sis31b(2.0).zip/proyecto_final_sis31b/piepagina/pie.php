<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Footer</title>
  <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
  <footer>    
  <hr color="purple" size=6>  
    <div class="container">
        <div class="columna1">
          <img src="Iconos/Logo.png">
        </div>
        <div class="columna2">
          <h1>O N L I N E</h1>
          <h3>SHOP</h3>
        </div>
        <div class="columna3">
          <img src="Iconos/facebook.png">
        </div>
        <div class="columna4">
          <img src="Iconos/twitter.png">
        
        </div>
        <div class="columna5">
          <img src="Iconos/whatsapp.png">
        </div>

    </div>
    <div class="container-parrafo">
      <h1>© 2021 Online Shop todos los derechos</h1>
      <h2>reservados.</h2>
    </div>
  </footer>
</body>
</html>