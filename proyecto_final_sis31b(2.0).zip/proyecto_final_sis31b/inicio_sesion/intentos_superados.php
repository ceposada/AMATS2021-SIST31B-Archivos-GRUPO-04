<?php 
	
	echo "Su cuenta ha sido deshabilitada hasta nuevo aviso por haber superado la cantidad máxima de intentos, por favor consulte a: carlos.posada20@itca.edu.sv para recuperar su cuenta o crear una nueva";

 ?>